import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Activity, Wallet, Bot, BarChart3, RefreshCw, AlertCircle } from 'lucide-react';

// Datos simulados - En producción, estos vendrían de la API de Binance
const mockData = {
  totalBalance: 45328.67,
  totalPnL24h: 1247.32,
  pnlPercentage: 2.83,
  
  futures: {
    totalMargin: 15420.50,
    availableMargin: 8934.22,
    unrealizedPnL: 342.18,
    positions: [
      { symbol: 'BTCUSDT', side: 'LONG', size: 0.5, entryPrice: 43250, markPrice: 43890, pnl: 320, leverage: '10x', margin: 2162.5 },
      { symbol: 'ETHUSDT', side: 'SHORT', size: 2.5, entryPrice: 2280, markPrice: 2271, pnl: 22.5, leverage: '5x', margin: 1140 },
      { symbol: 'SOLUSDT', side: 'LONG', size: 50, entryPrice: 98.5, markPrice: 98.4, pnl: -5, leverage: '3x', margin: 1641.67 }
    ]
  },
  
  spot: {
    totalValue: 28450.34,
    holdings: [
      { asset: 'BTC', amount: 0.342, valueUSD: 15010.58, change24h: 2.4 },
      { asset: 'ETH', amount: 4.82, valueUSD: 10942.44, change24h: 1.8 },
      { asset: 'BNB', amount: 8.5, valueUSD: 2497.32, change24h: -0.5 },
      { asset: 'USDT', amount: 0, valueUSD: 0, change24h: 0 }
    ]
  },
  
  bots: [
    { id: 1, name: 'Grid Bot BTC/USDT', pair: 'BTCUSDT', status: 'active', investment: 5000, profit: 287.45, profitPercent: 5.75, trades: 156 },
    { id: 2, name: 'DCA ETH Accumulator', pair: 'ETHUSDT', status: 'active', investment: 3000, profit: 142.80, profitPercent: 4.76, trades: 89 },
    { id: 3, name: 'Smart Rebalance', pair: 'Multi', status: 'paused', investment: 2500, profit: -34.20, profitPercent: -1.37, trades: 45 }
  ]
};

export default function BinanceDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [data, setData] = useState(mockData);
  const [lastUpdate, setLastUpdate] = useState(new Date());

  // Simulación de actualización de datos
  useEffect(() => {
    const interval = setInterval(() => {
      setLastUpdate(new Date());
      // Aquí irían las llamadas a la API de Binance
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(value);
  };

  const formatPercent = (value) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-400 bg-clip-text text-transparent mb-2" style={{ fontFamily: '"Orbitron", monospace' }}>
              BINANCE DASHBOARD
            </h1>
            <p className="text-slate-400 text-sm flex items-center gap-2">
              <Activity size={14} className="text-green-400 animate-pulse" />
              Última actualización: {lastUpdate.toLocaleTimeString()}
            </p>
          </div>
          <button className="bg-slate-800/50 backdrop-blur border border-slate-700 px-4 py-2 rounded-lg hover:bg-slate-700/50 transition-all flex items-center gap-2">
            <RefreshCw size={16} />
            Actualizar
          </button>
        </div>
        
        {/* Balance Total */}
        <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border border-amber-500/20 rounded-2xl p-8 shadow-2xl shadow-amber-500/10 mt-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-slate-400 text-sm mb-2">Balance Total</p>
              <h2 className="text-5xl font-bold mb-3" style={{ fontFamily: '"Orbitron", monospace' }}>{formatCurrency(data.totalBalance)}</h2>
              <div className="flex items-center gap-2">
                {data.totalPnL24h >= 0 ? <TrendingUp className="text-green-400" size={20} /> : <TrendingDown className="text-red-400" size={20} />}
                <span className={`text-xl font-semibold ${data.totalPnL24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {formatCurrency(data.totalPnL24h)} ({formatPercent(data.pnlPercentage)})
                </span>
                <span className="text-slate-500 text-sm">24h</span>
              </div>
            </div>
            <div className="text-right">
              <Wallet className="text-amber-400 mb-2" size={48} />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto mb-6">
        <div className="flex gap-2 bg-slate-900/50 backdrop-blur p-1 rounded-xl border border-slate-800">
          {[
            { id: 'overview', label: 'Vista General', icon: BarChart3 },
            { id: 'futures', label: 'Futuros', icon: TrendingUp },
            { id: 'spot', label: 'Spot', icon: Wallet },
            { id: 'bots', label: 'Bots', icon: Bot }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all font-semibold ${
                activeTab === tab.id 
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-900 shadow-lg shadow-amber-500/50' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto">
        {/* FUTURES TAB */}
        {activeTab === 'futures' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl p-6">
                <p className="text-slate-400 text-sm mb-2">Margen Total</p>
                <p className="text-3xl font-bold text-amber-400">{formatCurrency(data.futures.totalMargin)}</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl p-6">
                <p className="text-slate-400 text-sm mb-2">Margen Disponible</p>
                <p className="text-3xl font-bold text-green-400">{formatCurrency(data.futures.availableMargin)}</p>
              </div>
              <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl p-6">
                <p className="text-slate-400 text-sm mb-2">PnL No Realizado</p>
                <p className={`text-3xl font-bold ${data.futures.unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {formatCurrency(data.futures.unrealizedPnL)}
                </p>
              </div>
            </div>

            <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl overflow-hidden">
              <div className="p-6 border-b border-slate-700">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <TrendingUp className="text-amber-400" />
                  Posiciones Abiertas
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-900/50">
                    <tr>
                      <th className="text-left p-4 text-slate-400 font-semibold">Símbolo</th>
                      <th className="text-left p-4 text-slate-400 font-semibold">Lado</th>
                      <th className="text-right p-4 text-slate-400 font-semibold">Tamaño</th>
                      <th className="text-right p-4 text-slate-400 font-semibold">Precio Entrada</th>
                      <th className="text-right p-4 text-slate-400 font-semibold">Precio Mark</th>
                      <th className="text-right p-4 text-slate-400 font-semibold">Apalancamiento</th>
                      <th className="text-right p-4 text-slate-400 font-semibold">PnL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.futures.positions.map((pos, idx) => (
                      <tr key={idx} className="border-t border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                        <td className="p-4 font-bold text-amber-400">{pos.symbol}</td>
                        <td className="p-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            pos.side === 'LONG' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {pos.side}
                          </span>
                        </td>
                        <td className="text-right p-4">{pos.size}</td>
                        <td className="text-right p-4">${pos.entryPrice.toLocaleString()}</td>
                        <td className="text-right p-4">${pos.markPrice.toLocaleString()}</td>
                        <td className="text-right p-4">
                          <span className="px-2 py-1 bg-slate-700 rounded text-amber-400 font-semibold text-sm">
                            {pos.leverage}
                          </span>
                        </td>
                        <td className={`text-right p-4 font-bold ${pos.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {formatCurrency(pos.pnl)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* SPOT TAB */}
        {activeTab === 'spot' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl p-6">
              <p className="text-slate-400 text-sm mb-2">Valor Total Spot</p>
              <p className="text-4xl font-bold text-amber-400">{formatCurrency(data.spot.totalValue)}</p>
            </div>

            <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl overflow-hidden">
              <div className="p-6 border-b border-slate-700">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <Wallet className="text-amber-400" />
                  Holdings
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
                {data.spot.holdings.map((holding, idx) => (
                  <div key={idx} className="bg-slate-900/50 border border-slate-700 rounded-xl p-5 hover:border-amber-500/50 transition-all">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="text-2xl font-bold text-amber-400 mb-1">{holding.asset}</h4>
                        <p className="text-slate-400 text-sm">{holding.amount} tokens</p>
                      </div>
                      <div className={`flex items-center gap-1 px-2 py-1 rounded ${
                        holding.change24h >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'
                      }`}>
                        {holding.change24h >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                        <span className={`text-sm font-semibold ${holding.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {formatPercent(holding.change24h)}
                        </span>
                      </div>
                    </div>
                    <p className="text-3xl font-bold">{formatCurrency(holding.valueUSD)}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* BOTS TAB */}
        {activeTab === 'bots' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="grid grid-cols-1 gap-6">
              {data.bots.map(bot => (
                <div key={bot.id} className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-xl p-6 hover:border-amber-500/50 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-gradient-to-br from-amber-500 to-yellow-500 p-3 rounded-lg">
                        <Bot className="text-slate-900" size={24} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold">{bot.name}</h3>
                        <p className="text-slate-400 text-sm">{bot.pair}</p>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
                      bot.status === 'active' 
                        ? 'bg-green-500/20 text-green-400 flex items-center gap-2' 
                        : 'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {bot.status === 'active' && <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />}
                      {bot.status === 'active' ? 'Activo' : 'Pausado'}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    <div>
                      <p className="text-slate-400 text-sm mb-1">Inversión</p>
                      <p className="text-xl font-bold">{formatCurrency(bot.investment)}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm mb-1">Ganancia</p>
                      <p className={`text-xl font-bold ${bot.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {formatCurrency(bot.profit)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm mb-1">ROI</p>
                      <p className={`text-xl font-bold ${bot.profitPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {formatPercent(bot.profitPercent)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-400 text-sm mb-1">Trades</p>
                      <p className="text-xl font-bold text-amber-400">{bot.trades}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle className="text-blue-400 flex-shrink-0 mt-1" size={20} />
              <div>
                <p className="text-blue-400 font-semibold mb-1">Nota de Integración</p>
                <p className="text-slate-300 text-sm">
                  Para conectar con datos reales de Binance, necesitarás integrar la API oficial de Binance usando tus API keys. 
                  Esta demo muestra datos simulados para prototipar la interfaz.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Resumen Futuros */}
              <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <TrendingUp className="text-amber-400" />
                  Futuros
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Posiciones Abiertas</span>
                    <span className="font-bold text-amber-400">{data.futures.positions.length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Margen Usado</span>
                    <span className="font-bold">{formatCurrency(data.futures.totalMargin - data.futures.availableMargin)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">PnL No Realizado</span>
                    <span className={`font-bold ${data.futures.unrealizedPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {formatCurrency(data.futures.unrealizedPnL)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Resumen Spot */}
              <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Wallet className="text-amber-400" />
                  Spot
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Activos</span>
                    <span className="font-bold text-amber-400">{data.spot.holdings.filter(h => h.amount > 0).length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Valor Total</span>
                    <span className="font-bold">{formatCurrency(data.spot.totalValue)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Top Holding</span>
                    <span className="font-bold text-green-400">BTC</span>
                  </div>
                </div>
              </div>

              {/* Resumen Bots */}
              <div className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur border border-slate-700 rounded-xl p-6 md:col-span-2">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Bot className="text-amber-400" />
                  Bots de Trading
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Total Bots</p>
                    <p className="text-2xl font-bold text-amber-400">{data.bots.length}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Activos</p>
                    <p className="text-2xl font-bold text-green-400">{data.bots.filter(b => b.status === 'active').length}</p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Ganancia Total</p>
                    <p className="text-2xl font-bold text-green-400">
                      {formatCurrency(data.bots.reduce((sum, bot) => sum + bot.profit, 0))}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm mb-1">ROI Promedio</p>
                    <p className="text-2xl font-bold text-amber-400">
                      {formatPercent(data.bots.reduce((sum, bot) => sum + bot.profitPercent, 0) / data.bots.length)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap');
        
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
